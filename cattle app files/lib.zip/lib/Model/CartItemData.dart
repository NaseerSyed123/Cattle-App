class cartItem{
  String img,title,desc,price;
  int id,totalPrice;
  cartItem({
    this.id,
   this.img,
    this.title,
    this.desc,
    this.price,
    this.totalPrice
});
}