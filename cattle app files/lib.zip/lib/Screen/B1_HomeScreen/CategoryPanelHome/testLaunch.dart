import 'package:cattle_app/Screen/B1_HomeScreen/CategoryPanelHome/catView.dart' as cat;
void main() {
  cat.CatView();
}