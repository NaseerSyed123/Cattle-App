import 'package:flutter/material.dart';

class WeekAppointments extends StatefulWidget {
  @override
  _WeekAppointmentsState createState() => _WeekAppointmentsState();
}

class _WeekAppointmentsState extends State<WeekAppointments> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
