import 'package:flutter/material.dart';

class MonthAppointments extends StatefulWidget {
  @override
  _MonthAppointmentsState createState() => _MonthAppointmentsState();
}

class _MonthAppointmentsState extends State<MonthAppointments> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
