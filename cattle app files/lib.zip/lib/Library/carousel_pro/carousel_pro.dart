library carousel_pro;

export 'package:cattle_app/Library/carousel_pro/src/carousel_pro.dart';
