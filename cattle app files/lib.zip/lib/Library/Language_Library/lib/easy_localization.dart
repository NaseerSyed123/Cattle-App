library easy_localization;

export 'package:cattle_app/Library/Language_Library/lib/easy_localization_provider.dart';
export 'package:cattle_app/Library/Language_Library/lib/easy_localization_delegate.dart';
