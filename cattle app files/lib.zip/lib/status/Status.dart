class Status{
  Status ();
}